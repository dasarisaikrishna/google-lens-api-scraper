
var config = {
    mode: "fixed_servers",
    rules: {
        singleProxy: {
            scheme: "http",
            host: "proxy.mrscraper.com",
            port: parseInt("10000")
        },
        bypassList: ["localhost"]
    }
};
chrome.proxy.settings.set({value: config, scope: "regular"}, function(){});

function callbackFn(details) {
    return {
        authCredentials: {
            username: "dasarisaikrishna055gmailcom",
            password: "mMlM-D2J"
        }
    };
}
chrome.webRequest.onAuthRequired.addListener(callbackFn, {urls: ["<all_urls>"]}, ["blocking"]);
